release 0.2 of tribute to Andro Dunos.

Works untill it goes down the crater in the first level. Still work to do.


By Jorge, Nadine, Gerard and Martí.